import { ContactHero } from "@/components/ContactHero";
import { ContactFormSection } from "@/components/ContactFormSection";
import { Reviews } from "@/components/Reviews";
import { Location } from "@/components/Location";
import { Footer } from "@/components/Footer";
import { useSEO } from "@/hooks/use-seo";
import { SITE } from "@/lib/site";

const Contact = () => {
  useSEO({
    title: `Contact Us | ${SITE.businessName}`,
    description: `Contact ${SITE.businessName} for expert auto body repair in Indianapolis, IN. Collision, frame, paint & rust repair on E 26th St. Call ${SITE.phone}.`,
  });
  return (
    <div className="min-h-screen bg-background">
      <main>
        <ContactHero />
        <ContactFormSection />
        <Reviews />
        <Location />
      </main>
      <Footer />
    </div>
  );
};

export default Contact;
