import { Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { useNavigate } from "react-router-dom";
import { postTrackingEvent } from "@/lib/tracking";
import { useRef, useState } from "react";

export const CareersFormSection = () => {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24 max-w-6xl mx-auto items-start">
          {/* Left Column: Text Content */}
          <div className="space-y-8">
            <h2 className="text-4xl lg:text-5xl font-heading font-extrabold text-slate-900">
              Join The Crew
            </h2>
            <p className="text-xl text-slate-800 leading-relaxed">
              We're always looking for skilled technicians and hard workers who
              take pride in their craft. If you're ready to join a crew that
              values your time and rewards your effort, we'd love to hear from
              you.
            </p>

            <div className="space-y-4 pt-2">
              <h3 className="text-2xl font-bold text-slate-900">
                What we offer:
              </h3>
              <ul className="space-y-2 text-xl text-slate-800">
                <li className="flex items-center gap-3">
                  <span className="text-slate-900 font-bold text-2xl">
                    &gt;
                  </span>{" "}
                  Competitive pay
                </li>
                <li className="flex items-center gap-3">
                  <span className="text-slate-900 font-bold text-2xl">
                    &gt;
                  </span>{" "}
                  Healthy work-life balance
                </li>
                <li className="flex items-center gap-3">
                  <span className="text-slate-900 font-bold text-2xl">
                    &gt;
                  </span>{" "}
                  Great culture
                </li>
              </ul>
            </div>

            <p className="text-xl text-slate-800 pt-4">
              Fill out the form below and we'll be in touch.
            </p>
          </div>

          {/* Right Column: Application Form */}
          <div className="bg-slate-100 p-8 md:p-10 rounded-xl border border-slate-200">
            <form
              className="space-y-6"
              onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget);

                postTrackingEvent(
                  {
                    type: "external_form_submission",
                    timestamp: Date.now(),
                    formId: "Careers Form",
                    formData: {
                      first_name: formData.get("name"),
                      email: formData.get("email"),
                      phone: formData.get("phone"),
                    },
                    formLabels: {
                      first_name: "Name",
                      email: "Email",
                      phone: "Phone",
                    },
                    url: window.location.href,
                    title: document.title,
                    path: window.location.pathname,
                    userAgent: navigator.userAgent,
                    trackingId: "tk_da7e31b94d6e4349bfca5fcad8d57134",
                    locationId: "8FDxOJay7azO4EdDwUZw",
                    sessionId: crypto.randomUUID(),
                    properties: {
                      deviceType: /Mobile|Android|iPhone/i.test(
                        navigator.userAgent,
                      )
                        ? "mobile"
                        : "desktop",
                    },
                  },
                  {
                    fileFields: selectedFile
                      ? {
                          hsRkqlGgJRufVNkRuLoO: {
                            file: selectedFile,
                            label: "Resume",
                          },
                        }
                      : {},
                  },
                );

                navigate("/thank-you");
              }}
            >
              <div className="space-y-4">
                <Input
                  name="name"
                  placeholder="John Smith*"
                  required
                  className="bg-white border-slate-300 text-slate-900 placeholder:text-slate-900 font-medium h-14 text-lg rounded-md"
                />
                <Input
                  name="email"
                  type="email"
                  placeholder="your@email.com*"
                  required
                  className="bg-white border-slate-300 text-slate-900 placeholder:text-slate-900 font-medium h-14 text-lg rounded-md"
                />
                <Input
                  name="phone"
                  type="tel"
                  placeholder="(808) 555-1234*"
                  required
                  className="bg-white border-slate-300 text-slate-900 placeholder:text-slate-900 font-medium h-14 text-lg rounded-md"
                />
              </div>

              {/* File Upload Area */}
              <div
                className="border border-slate-300 rounded-md p-10 text-center bg-slate-100/50 hover:bg-slate-200/50 transition-colors cursor-pointer"
                onClick={() => fileInputRef.current?.click()}
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                  accept=".pdf,.doc,.docx,.xls,.csv,.jpg,.jpeg,.png,.gif"
                />
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm">
                  <Upload className="w-5 h-5 text-slate-800" />
                </div>
                <p className="font-bold text-slate-900 mb-2 text-lg">
                  {selectedFile
                    ? selectedFile.name
                    : "Click to upload your resume"}
                </p>
                <p className="text-xs text-slate-600 uppercase tracking-wider font-medium">
                  PDF, DOC/DOCX, XLS/CSV, JPG/JPEG, PNG, GIF
                </p>
              </div>

              <div className="flex items-start gap-3 pt-2">
                <Checkbox
                  id="terms"
                  required
                  className="mt-1 bg-white border-slate-300 data-[state=checked]:bg-primary data-[state=checked]:border-primary rounded-sm"
                />
                <label
                  htmlFor="terms"
                  className="text-sm text-slate-800 leading-snug cursor-pointer select-none"
                >
                  I agree to{" "}
                  <a href="#" className="underline font-medium text-slate-900">
                    terms & conditions
                  </a>{" "}
                  provided by the company. By providing my phone number, I agree
                  to receive text messages from the business.
                </label>
              </div>

              <Button
                type="submit"
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground h-14 text-xl font-bold mt-4 uppercase tracking-wider rounded-md"
              >
                Send
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};
