import { Button } from "@/components/ui/button";
import { MapPin, Phone, Clock } from "lucide-react";
import { MapEmbed } from "./MapEmbed";
import { Link } from "react-router-dom";
import { SITE } from "@/lib/site";

export const ServiceLocation = ({
  serviceName,
  paragraphs,
}: {
  serviceName: string;
  paragraphs: string[];
}) => {
  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          <div className="space-y-6 lg:order-1 order-2">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 leading-tight">
              {serviceName} Near {SITE.city}, {SITE.state}
            </h2>
            {paragraphs.map((p, i) => (
              <p
                key={i}
                className="text-lg text-slate-600 leading-relaxed"
                dangerouslySetInnerHTML={{ __html: p }}
              />
            ))}
          </div>
          <div className="lg:order-2 order-1">
            <div className="bg-white p-6 rounded-2xl shadow-xl border border-slate-200 space-y-6">
              <div className="space-y-4">
                <div className="flex gap-4 items-start">
                  <MapPin className="w-6 h-6 text-primary shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-slate-900">{SITE.street}</p>
                    <p className="text-slate-600">{SITE.streetCity}</p>
                  </div>
                </div>

                <div className="flex gap-4 items-center">
                  <Phone className="w-6 h-6 text-primary shrink-0" />
                  <a
                    href={SITE.phoneHref}
                    className="font-bold text-slate-900 hover:text-primary transition-colors"
                  >
                    {SITE.phone}
                  </a>
                </div>

                <div className="flex gap-4 items-start">
                  <Clock className="w-6 h-6 text-primary shrink-0 mt-0.5" />
                  <div className="text-slate-900">
                    <p>
                      <span className="font-bold">Mon–Fri:</span> 9:00 AM – 5:00
                      PM
                    </p>
                    <p>
                      <span className="font-bold">Saturday:</span> Closed
                    </p>
                    <p>
                      <span className="font-bold">Sunday:</span> Closed
                    </p>
                  </div>
                </div>
              </div>

              <Button
                asChild
                className="bg-primary hover:bg-primary/90 text-white font-bold px-8 py-6 rounded-full text-lg w-full"
              >
                <a
                  href={SITE.mapsLink}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Get directions
                </a>
              </Button>

              <div className="rounded-xl overflow-hidden shadow-sm border border-slate-200 bg-white">
                <MapEmbed />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export { Link };
