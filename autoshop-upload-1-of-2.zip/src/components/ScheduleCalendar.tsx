import { useState, useEffect, useMemo } from "react";
import { format, startOfMonth, endOfMonth } from "date-fns";
import { Calendar } from "@/components/ui/calendar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Loader2, ArrowLeft } from "lucide-react";

const BOOKING_API_URL = "https://backend.leadconnectorhq.com";
const VIBE_API_URL = "https://backend.leadconnectorhq.com/vibe-ai";
const LOCATION_ID = "8FDxOJay7azO4EdDwUZw";
const CALENDAR_ID = "7LWCW1NMkU2GJJ5oqJxP";

const getBrowserTimezone = () =>
  Intl.DateTimeFormat().resolvedOptions().timeZone;

const clampAvailabilityRange = (startMs: number, endMs: number) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const startDate = Math.max(startMs, today.getTime());
  const maxEndDate = startDate + 31 * 24 * 60 * 60 * 1000;
  const endDate = Math.min(Math.max(endMs, startDate), maxEndDate);

  return { startDate, endDate };
};

const fetchCalendarFreeSlots = async (
  calendarId: string,
  startMs: number,
  endMs: number,
) => {
  const { startDate, endDate } = clampAvailabilityRange(startMs, endMs);
  const params = new URLSearchParams({
    startDate: String(startDate),
    endDate: String(endDate),
    timezone: getBrowserTimezone(),
  });

  const response = await fetch(
    `${BOOKING_API_URL}/calendars/${calendarId}/free-slots?${params}`,
  );
  if (!response.ok) throw new Error("Failed to fetch calendar availability");
  return response.json();
};

type RegisteredCustomFieldId = string;
type CustomFieldValue = { id: RegisteredCustomFieldId; field_value: string };
type BookingPayload = {
  locationId: string;
  calendarId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  selectedSlot: string;
  selectedTimezone?: string;
  sessionId?: string;
  customFields?: CustomFieldValue[];
} & Partial<
  Record<
    | "notes"
    | "address1"
    | "city"
    | "state"
    | "postalCode"
    | "country"
    | "companyName"
    | "website"
    | "gender"
    | "dateOfBirth"
    | "timezone",
    string
  >
>;

const submitCalendarBooking = async (payload: BookingPayload) => {
  const response = await fetch(`${VIBE_API_URL}/booking/submit`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      ...payload,
      selectedTimezone: payload.selectedTimezone ?? getBrowserTimezone(),
      sessionId: payload.sessionId ?? crypto.randomUUID(),
      customFields: payload.customFields ?? [],
    }),
  });

  if (!response.ok) throw new Error("Booking submission failed");
  return response.json();
};

export const ScheduleCalendar = () => {
  const { toast } = useToast();
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [month, setMonth] = useState<Date>(new Date());
  const [slots, setSlots] = useState<Record<string, { slots: string[] }>>({});
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);

  const [step, setStep] = useState<"date" | "form" | "success">("date");
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const loadSlots = async () => {
      setLoadingSlots(true);
      try {
        const start = startOfMonth(month).getTime();
        const end = endOfMonth(month).getTime();
        const data = await fetchCalendarFreeSlots(CALENDAR_ID, start, end);
        setSlots(data);
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to load availability. Please try again.",
          variant: "destructive",
        });
      } finally {
        setLoadingSlots(false);
      }
    };
    loadSlots();
  }, [month, toast]);

  const selectedDateStr = date ? format(date, "yyyy-MM-dd") : null;
  const availableSlotsForDate = selectedDateStr
    ? slots[selectedDateStr]?.slots || []
    : [];

  const handleBooking = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedSlot) return;

    const formData = new FormData(e.currentTarget);
    const fullName = formData.get("fullName") as string;
    const [firstName, ...lastNameParts] = fullName.split(" ");
    const lastName = lastNameParts.join(" ") || " ";

    setIsSubmitting(true);
    try {
      await submitCalendarBooking({
        locationId: LOCATION_ID,
        calendarId: CALENDAR_ID,
        firstName,
        lastName,
        email: formData.get("email") as string,
        phone: formData.get("phone") as string,
        notes: formData.get("notes") as string,
        selectedSlot,
      });
      setStep("success");
    } catch (error) {
      toast({
        title: "Booking Failed",
        description:
          "There was an error scheduling your appointment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="py-20 bg-white text-slate-900">
      <div className="container mx-auto px-4 max-w-5xl">
        <div className="bg-white p-4 md:p-8 rounded-xl border border-slate-200 min-h-[600px] shadow-sm">
          {step === "date" && (
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h2 className="text-2xl font-bold mb-6 text-slate-900">
                  Select a Date
                </h2>
                <div className="border rounded-lg p-4 bg-slate-50 flex justify-center text-slate-900">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={(d) => {
                      setDate(d);
                      setSelectedSlot(null);
                    }}
                    onMonthChange={setMonth}
                    disabled={(d) => {
                      const today = new Date();
                      today.setHours(0, 0, 0, 0);
                      if (d < today) return true;

                      const dateStr = format(d, "yyyy-MM-dd");
                      return (
                        !slots[dateStr] || slots[dateStr].slots.length === 0
                      );
                    }}
                    modifiers={{
                      available: (d) => {
                        const today = new Date();
                        today.setHours(0, 0, 0, 0);
                        if (d < today) return false;
                        const dateStr = format(d, "yyyy-MM-dd");
                        return !!(
                          slots[dateStr] && slots[dateStr].slots.length > 0
                        );
                      },
                    }}
                    modifiersClassNames={{
                      available:
                        "text-primary font-bold bg-primary/5 hover:bg-primary/10",
                    }}
                    className="bg-white rounded-md shadow-sm border border-slate-100"
                  />
                </div>
              </div>

              <div>
                <h2 className="text-2xl font-bold mb-6 text-slate-900">
                  Select a Time
                </h2>
                {loadingSlots && !date ? (
                  <div className="flex justify-center items-center h-64 border-2 border-dashed border-slate-200 rounded-lg bg-slate-50">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : !date ? (
                  <div className="flex justify-center items-center h-64 border-2 border-dashed border-slate-200 rounded-lg bg-slate-50">
                    <p className="text-slate-500">Please select a date first</p>
                  </div>
                ) : availableSlotsForDate.length === 0 ? (
                  <div className="flex justify-center items-center h-64 border-2 border-dashed border-slate-200 rounded-lg bg-slate-50">
                    <p className="text-slate-500">
                      No available times for this date
                    </p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-[400px] overflow-y-auto pr-2">
                      {availableSlotsForDate.map((slot) => {
                        const slotDate = new Date(slot);
                        return (
                          <Button
                            key={slot}
                            variant="outline"
                            className={`w-full h-12 rounded-md text-base font-semibold border-2 border-primary transition-colors ${
                              selectedSlot === slot
                                ? "bg-primary text-white hover:bg-primary/90 hover:text-white"
                                : "bg-transparent text-primary hover:bg-primary/10"
                            }`}
                            onClick={() => setSelectedSlot(slot)}
                          >
                            {format(slotDate, "h:mm a")}
                          </Button>
                        );
                      })}
                    </div>

                    {selectedSlot && (
                      <Button
                        className="w-full h-14 text-lg font-bold uppercase tracking-wide bg-primary hover:bg-primary/90 text-white rounded-md"
                        onClick={() => setStep("form")}
                      >
                        Continue to Details
                      </Button>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {step === "form" && (
            <div className="max-w-2xl mx-auto">
              <Button
                variant="ghost"
                className="mb-6 -ml-4"
                onClick={() => setStep("date")}
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Time Selection
              </Button>

              <div className="mb-8 p-4 bg-slate-50 rounded-lg border border-slate-200">
                <h3 className="font-semibold text-lg mb-1">Selected Time</h3>
                <p className="text-slate-600">
                  {selectedSlot &&
                    format(
                      new Date(selectedSlot),
                      "EEEE, MMMM d, yyyy 'at' h:mm a",
                    )}
                </p>
              </div>

              <form onSubmit={handleBooking} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="fullName" className="sr-only">
                    Full Name
                  </Label>
                  <Input
                    id="fullName"
                    name="fullName"
                    placeholder="John Smith*"
                    required
                    className="h-14 bg-white border-slate-200 rounded-md text-base px-4 shadow-sm"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="sr-only">
                    Email Address
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="your@email.com*"
                    required
                    className="h-14 bg-white border-slate-200 rounded-md text-base px-4 shadow-sm"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="sr-only">
                    Phone Number
                  </Label>
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    placeholder="(808) 555-1234*"
                    required
                    className="h-14 bg-white border-slate-200 rounded-md text-base px-4 shadow-sm"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes" className="sr-only">
                    Additional Notes
                  </Label>
                  <Textarea
                    id="notes"
                    name="notes"
                    placeholder="Tell us about your vehicle and what service you need..."
                    className="min-h-[120px] bg-white border-slate-200 rounded-md text-base p-4 shadow-sm"
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full h-14 text-lg font-bold uppercase tracking-wide bg-primary hover:bg-primary/90 text-white rounded-md mt-6"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Scheduling...
                    </>
                  ) : (
                    "Confirm Appointment"
                  )}
                </Button>
              </form>
            </div>
          )}

          {step === "success" && (
            <div className="max-w-md mx-auto text-center py-12">
              <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg
                  className="w-10 h-10"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
              <h2 className="text-3xl font-bold mb-4">
                Appointment Confirmed!
              </h2>
              <p className="text-slate-600 mb-8 text-lg">
                Thank you for scheduling with us. We've sent a confirmation
                email with your appointment details.
              </p>
              <Button
                onClick={() => {
                  setStep("date");
                  setDate(undefined);
                  setSelectedSlot(null);
                }}
                variant="outline"
              >
                Schedule Another Appointment
              </Button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
