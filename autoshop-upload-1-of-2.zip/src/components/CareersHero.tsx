export const CareersHero = () => {
  return (
    <section className="relative pb-20 lg:pb-28 overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img
          src="https://vibe.filesafe.space/1788452106586755470/assets/aa7a64dd-c7ba-406f-a4bb-eeedffce396c.png"
          alt="Auto mechanic working"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-slate-900/80 mix-blend-multiply"></div>
      </div>
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl">
          <h1 className="text-4xl md:text-5xl lg:text-7xl font-heading font-extrabold text-white mb-6 leading-tight">
            Build Your Career With Us
          </h1>
          <p className="text-xl md:text-2xl text-slate-200 font-medium leading-relaxed max-w-3xl">
            Join a team that keeps America's drivers moving and takes care of
            its people while doing it.
          </p>
        </div>
      </div>
    </section>
  );
};
