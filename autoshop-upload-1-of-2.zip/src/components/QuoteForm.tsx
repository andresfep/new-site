import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Lock } from "lucide-react";
import { postTrackingEvent } from "@/lib/tracking";

const formatPhone = (raw: string) => {
  const d = raw.replace(/\D/g, "").slice(0, 10);
  return d.length > 6
    ? `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6)}`
    : d.length > 3
      ? `(${d.slice(0, 3)}) ${d.slice(3)}`
      : d.length > 0
        ? `(${d}`
        : "";
};

interface QuoteFormProps {
  onSuccess?: () => void;
}

export const QuoteForm = ({ onSuccess }: QuoteFormProps) => {
  const navigate = useNavigate();
  const [phone, setPhone] = useState("");

  return (
    <form
      className="space-y-4"
      onSubmit={(e) => {
        e.preventDefault();
        const formData = new FormData(e.currentTarget);

        postTrackingEvent(
          {
            type: "external_form_submission",
            timestamp: Date.now(),
            formId: "quote form",
            formData: {
              full_name: formData.get("name"),
              phone: formData.get("phone"),
              email: formData.get("email"),
            },
            formLabels: {
              full_name: "Full Name",
              phone: "Phone",
              email: "Email",
            },
            url: window.location.href,
            title: document.title,
            path: window.location.pathname,
            userAgent: navigator.userAgent,
            trackingId: "tk_da7e31b94d6e4349bfca5fcad8d57134",
            locationId: "8FDxOJay7azO4EdDwUZw",
            sessionId: crypto.randomUUID(),
            properties: {
              deviceType: /Mobile|Android|iPhone/i.test(navigator.userAgent)
                ? "mobile"
                : "desktop",
            },
          },
          {
            customFields: {
              nbROqzsy7dgGlVZc2UyB: {
                value: formData.get("service"),
                label: "Service",
              },
              NggyD435SXDPi8TM3gM0: {
                value: formData.get("vehicle"),
                label: "Vehicle",
              },
              QYzFS87j9JN15XJcObLN: {
                value: formData.get("message"),
                label: "Your Message",
              },
            },
          },
        );

        if (onSuccess) onSuccess();
        else navigate("/thank-you");
      }}
    >
      <div>
        <Input
          name="name"
          placeholder="John Smith*"
          className="bg-gray-50 border-gray-200 text-slate-900 placeholder:text-gray-400"
          required
        />
      </div>
      <div>
        <Input
          name="phone"
          placeholder="(555) 555-1234*"
          type="tel"
          value={phone}
          onChange={(e) => setPhone(formatPhone(e.target.value))}
          className="bg-gray-50 border-gray-200 text-slate-900 placeholder:text-gray-400"
          required
        />
      </div>
      <div>
        <Input
          name="email"
          placeholder="your@email.com*"
          type="email"
          className="bg-gray-50 border-gray-200 text-slate-900 placeholder:text-gray-400"
          required
        />
      </div>
      <div>
        <Input
          name="service"
          placeholder="What service do you need?"
          className="bg-gray-50 border-gray-200 text-slate-900 placeholder:text-gray-400"
        />
      </div>
      <div>
        <Input
          name="vehicle"
          placeholder="What vehicle do you have?"
          className="bg-gray-50 border-gray-200 text-slate-900 placeholder:text-gray-400"
        />
      </div>
      <div>
        <Textarea
          name="message"
          placeholder="**Your message goes straight to my phone, I'll get back to you as soon as I'm available***"
          className="bg-gray-50 border-gray-200 text-slate-900 placeholder:text-gray-400 min-h-[80px] resize-none text-sm"
        />
      </div>
      <div className="flex items-start space-x-2 pt-2">
        <Checkbox id="quote-terms" className="mt-1" />
        <Label
          htmlFor="quote-terms"
          className="text-xs text-gray-500 font-normal leading-tight"
        >
          I agree to terms &amp; conditions provided by the company. By
          providing my phone number, I agree to receive text messages from the
          business.
        </Label>
      </div>
      <div className="pt-2">
        <Button className="w-full bg-primary hover:bg-primary/90 text-white font-bold text-lg h-14">
          Get My Free Quote Request
        </Button>
        <p className="text-center text-xs text-gray-500 mt-3 flex items-center justify-center gap-1">
          <Lock className="w-3 h-3" />
          No Obligation. We'll review info and follow up fast.
        </p>
      </div>
    </form>
  );
};

export default QuoteForm;
