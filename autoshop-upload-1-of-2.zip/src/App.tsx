import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import Index from "./pages/Index";
import ServicePage from "./pages/ServicePage";
import ServiceAreaPage from "./pages/ServiceAreaPage";
import NotFound from "./pages/NotFound";

import Contact from "./pages/Contact";
import ThankYou from "./pages/ThankYou";
import ReviewsPage from "./pages/ReviewsPage";
import GalleryPage from "./pages/GalleryPage";
import AboutUsPage from "./pages/AboutUsPage";
import { QuoteModalProvider } from "./components/QuoteModal";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsOfService from "./pages/TermsOfService";
import ReviewEmbed from "./pages/ReviewEmbed";
import MarketingEmbed from "./pages/MarketingEmbed";
import DiscountEmbed from "./pages/DiscountEmbed";
import ReleaseForm from "./pages/ReleaseForm";
import { NotificationBar, SpanishBanner } from "./components/NotificationBar";
import { Header } from "./components/Header";
import { MobileFooter } from "./components/MobileFooter";
import { ScrollToTop } from "./components/ScrollToTop";
import { SERVICES, AREAS } from "@/lib/site";

const queryClient = new QueryClient();

const bareRoutes = ["/review", "/marketing", "/get-your-discount"];

const ConditionalChrome = () => {
  const location = useLocation();
  if (bareRoutes.includes(location.pathname)) return null;
  return (
    <>
      <div className="sticky top-0 z-50 bg-background">
        <NotificationBar />
        <Header />
        <SpanishBanner />
      </div>
      <MobileFooter />
    </>
  );
};

const serviceRoutes = SERVICES.map((s) => (
  <Route
    key={s.slug}
    path={`/${s.slug}`}
    element={<ServicePage slug={s.slug} />}
  />
));

const areaRoutes = AREAS.map((a) => (
  <Route
    key={a.slug}
    path={`/${a.slug}`}
    element={<ServiceAreaPage slug={a.slug} />}
  />
));

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <ScrollToTop />
        <QuoteModalProvider>
          <div className="min-h-screen bg-background">
            <ConditionalChrome />
            <div>
              <Routes>
                <Route path="/" element={<Index />} />
                {serviceRoutes}
                {areaRoutes}
                <Route path="/contact" element={<Contact />} />
                <Route path="/thank-you" element={<ThankYou />} />
                <Route path="/reviews" element={<ReviewsPage />} />
                <Route path="/gallery" element={<GalleryPage />} />
                <Route path="/about-us" element={<AboutUsPage />} />
                <Route path="/marketing" element={<MarketingEmbed />} />
                <Route path="/review" element={<ReviewEmbed />} />
                <Route path="/get-your-discount" element={<DiscountEmbed />} />
                <Route path="/release-form" element={<ReleaseForm />} />
                <Route path="/privacy" element={<PrivacyPolicy />} />
                <Route path="/terms" element={<TermsOfService />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </div>
          </div>
        </QuoteModalProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
